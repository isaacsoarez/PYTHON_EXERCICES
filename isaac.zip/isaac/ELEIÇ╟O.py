print('-----ELEIÇÃO-----')
votantes = int(input("Digite o número de eleitores:"))

candidato1= 0
candidato2= 0
candidato3= 0

for eleitor in range(1, votantes + 1):
        while True:
                print(f"Eleitor {eleitor}:")
                print("1 - Candidato 1")
                print("2 - Candidato 2")
                print("3 - Candidato 3")

                voto = int(input("Digite o número do candidato escolhido: "))

                if voto == 1:
                        candidato1 += 1
                        break
                elif voto == 2:
                        candidato2 += 1
                        break
                elif voto == 3:
                        candidato3 += 1
                        break
                else:
                        print("Voto inválido. Tente novamente.")


print('O candidato teve ', {candidato1},'votos')
print('O candidato teve', {candidato2},'votos')
print('O candidato teve', {candidato3}, 'votos')