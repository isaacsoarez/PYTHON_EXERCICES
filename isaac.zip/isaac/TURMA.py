n=0
for n in range(4):
    n=float(input('Digite a idade dos 4 alunos da turma:'))
soma = n + n + n + n
media= soma/4
print(f'A soma das idades é', soma)
print(f'A média das idades é', media)
if media <25:
    print('A turma se encaixa na categoria (JOVEM)')
elif media >60:
    print('A turma se encaixa na categoria (IDOSA)')
else:
    print('A turma se encaixa na categoria (ADULTA)')