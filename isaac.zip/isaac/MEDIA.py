n=0
for n in range(5):
    n=float(input('Digite um número:'))
soma = n + n + n + n + n
print(f'A soma dos número é', soma)
print(f'A média dos número é', soma/5)