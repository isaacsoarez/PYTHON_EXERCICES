for number in range(5, 100):
    if(number %7 == 0 and number %5 !=0):
        print(number)