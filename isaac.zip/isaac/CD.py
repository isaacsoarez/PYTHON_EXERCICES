print('COLEÇÃO DE CDS')
cd=int(input('Digite o número de cds de sua coleção'))
vtotal = 0
a = 0
for i in range (cd):
       vcd = float(input('Digite o valor de cada um deles:'))
vtotal = vtotal + vcd
vmedio = vtotal/ vcd
a=a+1
print(f'O valor medio de sua coleção é de R$:', vmedio)
print(f'O valor total de sua coleção é de:', vtotal)